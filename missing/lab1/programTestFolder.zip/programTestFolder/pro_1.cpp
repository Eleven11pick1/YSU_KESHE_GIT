#include <iostream>
int main() {
    std::cout << "hello my world" << std::endl;
    return 0;
}
